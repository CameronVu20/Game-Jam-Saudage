/* VARIABLES */
//font
let font;
//title
let Tenter;
let screen = 0;

//dialogue
//let word;
let denialLoaded = false;
//let loadScript;
//next
let rose;
//player
let denial;
let anger;
//title
let title;
//food
let food;


/* PRELOAD LOADS FILES */
function preload() {
  //text
  font = loadFont("fonts/NanumPenScript-Regular.ttf");
  //title
  title = loadImage("assets/title.png");
  //denial
  denial = loadImage("assets/neutral.png");
  //next
  rose = loadImage("assets/next.png");
  preloadDenialAsset();
  //anger
  anger = loadImage("assets/anger.png");
  //food
  food = loadImage("assets/food.png");
}

/* SETUP RUNS ONCE */
function setup() {
  createCanvas(400, 400);
  textFont(font);

  //title button
  Tenter = new Sprite(200, 225, 150, 50);
  Tenter.text = "Enter";
  Tenter.color = "white";
  Tenter.textSize = 35;

  // next rose
  // roseSprite = new Sprite(rose, -200, -300, 50, 30);
  roseSprite = new Sprite(-200, -300, 250, 150);
  roseSprite.image = rose;
  // wait a damn minute...wait a damn minute (please excuse my language)
  // "I tend to do my best work between 1-2 am. That's when the revelations hit." ~ Rae, 2024
  roseSprite.scale = 0.2;
  roseSprite.collider = "s";
  // roseSprite.debug = true; // checking the collider
  // roseSprite.setCollider("rectangle", 0, 0, 50, 30);
  /* Could the issue be caused by the size of the collider? */
  //love that, you have cooked! I am processing info
  // I believe I've cooked.
  denial.resize(200, 0);
  anger.resize(200, 0);

  // Initalize the denial box off screen. Edit later in denial function
  word = new Sprite(-200, -200);
  setupDenial(-200, -200);

 
}

function draw() {
  print(screen);
  catcher.visible = false;
  puzzle.visible = false;
  
  if (screen == 0) {
    background(title);
    Tenter.visible = true;
    if (Tenter.mouse.presses()) {
      begin();
    }
  } else if (screen == 1) {
    background(0);
    denialDay();
    textSize(25);
    fill("black");
    text("Day 1 - Denial", 140, 320, 360, 360);
    textSize(15);
    text("click the rose (lower leaf) to go to the next page", 70, 340, 360, 360);
    if (roseSprite.mouse.presses()) {
      print("Clicked");
      screen = 2;
    }
  } else if (screen == 2) {
    background(0);
    denialDay();
    textSize(13);
    fill("black");
    text("*It's been awhile since you've been here. Avoiding your home as\n much as possible, staying over at friends' homes, and traveling \nback to your childhood home. But deep down, you know that you\n can't let this go. You know that you have to confront it one\n day, no matter how much it hurts.", 55, 290, 360, 360);
    if (roseSprite.mouse.presses()) {
      screen = 3;
    }
  } else if (screen == 3) {
    background(0);
    denialDay();
    textSize(13);
    fill("black");
    text("*Entering your room, you can see everything eactly as you\nleft it: clothes piling up in the corner, a cluttered desk covered\n in papers, and a half-made bed. The metronome ticking of the \ntiny cuckoo clock keeps you grounded.", 55, 290, 360, 360);
    if (roseSprite.mouse.presses()) {
      screen = 4;
    }
  } else if (screen == 4) {
    background(0);
    denialDay();
    textSize(13);
    fill("black");
    text("*Your reason for leaving laid still on your pillow A torn up piece\n of paper, a photo. You clutch the tiny torn up paper, trying\n to tape it back together.", 55, 290, 360, 360);
    if (roseSprite.mouse.presses()) {
      print("clicked!");
      screen = 5;
    }
  } else if (screen == 5) {
    denialScreen();
  } else if (screen == 6) {
    angerDial();
  } else if (screen == 7) {
    background(0);
    angerDay();
    textSize(13);
    fill("black");
    text("*You wake up to the sun rays pooling into your room.\n The photo taped together laid beside your head. You glance at it...", 55, 290, 360, 360);
    if (roseSprite.mouse.presses()) {
      screen = 8;
    } 
  }else if (screen == 8){
      background(0);
      angerDay();
      textSize(13);
      fill("black");
      text("*Your head is reeling, still tired from the night before.\n You lift the photo in front of your eyes. Instead of the\n familiar feeling of a bottomless pit in your stomach.\n You are met with a new fiery rage.",55, 290, 360, 360);
    if(roseSprite.mouse.presses()){ print("clicked");
      screen = 9;
    }
}else if(screen == 9){
      background(0);
      angerDay();
      textSize(13);
      fill("black");
      text("*Why doesn't anyone understand what you are going throught?\n Why can't people understand? why can't you recognize the\n person in the photo anymore? Why do they say they get it\n when they don't?", 55, 290, 360, 360);
    if(roseSprite.mouse.presses()){
      screen = 10;
    }
    } else if(screen == 10){
    background(0);
    angerDay();
    textSize(13);
    fill("black");
    text("You grab the corner of the photo ready to pull and rip it\n once again, but you have a new idea. Let's burn it.You\n already ripped it once. It wasn't permanent and fire will\n change it forever.", 55, 290, 360, 360);
    if(roseSprite.mouse.presses()){
      screen = 11;
    }
  } else if (screen == 11){
    background(0);
    angerDay();
    textSize(13);
    fill("black");
    text("*You search around the house, looking through drawers and \nunder things. Only to find bits and pieces of a broken lighter.\n Time to put it back together again.", 55, 290, 360, 360);
    if(roseSprite.mouse.presses()){
      screen = 12; 
    }
    } else if (screen == 12){
      print("Click");
      angerScreen();
    }
  }
//LMAOOOO, I think I know why 
// I think it's working now!
//anger dialouge start here
function angerDial(){
  print("anger dialouge");
    background(0);
    angerDay();
    textSize(25);
    fill("black");
    text("Day 1 - Anger", 140, 320, 360, 360);
if(roseSprite.mouse.presses()){
        screen = 7;
      } 
  }

function begin() {
  Tenter.remove();
  screen = 1;
  background(0);
}

function denialDay() {
  fill("white");
  rect(50, 270, 300, 100);
  // next button
  roseSprite.visible = true;
  roseSprite.pos = { x: 326, y: 235 };
  image(denial, 50, 90);
}
function angerDay(){
  fill("white");
  rect(50, 270, 300, 100);
  // next button
  roseSprite.visible = true;
  roseSprite.pos = { x: 326, y: 235 };
  image(anger, 50, 90);
}

/*function loadScript(url, callback) {
  var script = document.createElement("script");
  script.type = "text/javascript";
  script.src = url;

  script.onload = function() {
    callback;
  }
}*/

