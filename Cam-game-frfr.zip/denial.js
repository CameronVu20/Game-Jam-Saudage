/* VARIABLES */
let catcher, puzzle, roseSprite;
let catcherImg, puzzleImg, roseImg;;

// score
let score = 0;
//back button
/* PRELOAD LOADS FILES */
function preloadDenialAsset(){
  // catcher image
  catcherImg = loadImage("assets/catcher.png");
  // puzzle image
  puzzleImg = loadImage("assets/puzzle.png");
  // photo image
  photoImg = loadImage("assets/photo.png");
}

/* SETUP RUNS ONCE */
function setupDenial() {
  // resize images
  catcherImg.resize(100, 0);
  puzzleImg.resize(100, 0);
  photoImg.resize(300, 0);
  // Create catcher 
  catcher = new Sprite(catcherImg, 200, 380, 100, 20);
  catcher.color = color(0);
  catcher.collider = 'k';
  catcher.rotationLock = true;

  // Create falling object
  puzzle = new Sprite(puzzleImg, 100, 0, 10);
  puzzle.vel.y = random(1, 10);
  puzzle.collider = 'dynamic';
  puzzle.rotationLock = true;
}

function denialScreen(){
  background("white");
  catcher.visible = true;
  puzzle.visible = true;
  fill(0);
  textSize(12);
  text("Move the \ncatcher with the \nleft and right \narrow keys to \ncatch the falling \nobjects.", width -100, 20);

  roseSprite.visible = false;
  roseSprite.pos = {x: -200, y: -200};
  // move puzzle piece up
  if(puzzle){
  if (puzzle.y > 400){
    puzzle.y = 0;
    puzzle.x = random(width);
    puzzle.vel.y = random(1, 5);
    score = score + 0;
  }
  // catcher movement
  if (kb.pressing("left")){
    catcher.vel.x = -3;
  } else if (kb.pressing("right")){
    catcher.vel.x = 3;
  } else {
    catcher.vel.x = 0;
  }

  if(catcher.x < 50){
    catcher.x = 50;
  } else if (catcher.x > 350){
    catcher.x = 350;
  }
  // puzzle piece hits catcher
  if (puzzle.collides(catcher)){
    puzzle.x = random(width);
    puzzle.y = 0;
    puzzle.vel.y = random(1, 5);
    puzzle.direction = "down";
    score = score + 1;
  }

  //end 
  if(score == 10){
    background(0);
    image(photoImg, 50, 50);
    puzzle.visible = false;
    roseSprite.visible = true;
    roseSprite.pos = {x: 326, y: 300};
  } 
    if(roseSprite.mouse.presses()){
      print("clicked");
      screen = 6;
    } else if(screen == 6){
      angerDial();
    }
  } 
  // score
  fill(0, 128, 128);
  textSize(20);
  text("Score = " + score, 10, 30);
  //allSprites.debug = mouse.pressing();
}


