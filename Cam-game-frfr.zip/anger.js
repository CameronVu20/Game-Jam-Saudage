/*//Make an array
let enter;
let lighterImg;
//let lighter = [rectangle, circle, square];

function preloadAngerAssets(){
  lighterImg = loadImage("assets/lighter.png");
}
function setupAnger() {
  createCanvas(400, 400);
  lighterImg.resize(100, 0);
  //rectangle = new Sprite(200, 200, 100, 20);
 // circle = new Sprite(50, 50, 50);
  //square = new Sprite(100, 100, 100, 50);
 // enter = new Sprite(200, 225, 150, 50);
}

function angerScreen(){
  background("white");
  
  

  }

*/

